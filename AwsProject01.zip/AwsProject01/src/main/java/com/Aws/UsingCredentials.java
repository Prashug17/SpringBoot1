package com.Aws;

import java.util.Iterator;
import java.util.List;

import com.amazonaws.auth.AWSStaticCredentialsProvider;
import com.amazonaws.auth.BasicAWSCredentials;
import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.AmazonS3ClientBuilder;
import com.amazonaws.services.s3.model.Bucket;

public class UsingCredentials {

	public static void main(String[] args) {
		BasicAWSCredentials cred=new BasicAWSCredentials("AKIAZWHHMMGRU5BCW2WJ","j1sntPKPe81JwequR7cWC/xjXoIaH4C98vATNN5m");
		AmazonS3 s3 = AmazonS3ClientBuilder.standard().withCredentials(new AWSStaticCredentialsProvider(cred)).build();
		List<Bucket>buckets=s3.listBuckets(); 	
		for(Iterator iterator=buckets.iterator();iterator.hasNext();) { 		 
			Bucket bucket = (Bucket)iterator.next(); 		 
			System.out.println("Owner="+bucket.getOwner().getDisplayName()+"--Name of Bucket="+bucket.getName());
		}
	}
}
