package com.Aws;

import java.util.Iterator;
import java.util.List;

import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.AmazonS3ClientBuilder;
import com.amazonaws.services.s3.model.Bucket;

public class App {

	public static void main(String[] args) {
		System.out.println("Hello World");
		final AmazonS3 s3 =AmazonS3ClientBuilder.standard().build(); 		 
		List<Bucket>buckets=s3.listBuckets(); 		 
		for(Iterator iterator=buckets.iterator();iterator.hasNext();) { 		 
			Bucket bucket = (Bucket)iterator.next(); 		 
			System.out.println("Owner="+bucket.getOwner().getDisplayName()+"--Name of Bucket="+bucket.getName());
		}

	}

}
