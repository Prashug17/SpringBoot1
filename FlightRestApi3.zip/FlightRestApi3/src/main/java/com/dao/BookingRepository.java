package com.dao;

import org.springframework.data.repository.CrudRepository;

import com.model.Booking;

public interface BookingRepository extends CrudRepository<Booking, Integer>{

}
