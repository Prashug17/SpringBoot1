package com.example.demo;

import static org.assertj.core.api.Assertions.assertThat;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JunitApplicationTests {

	Calculator cal=new Calculator();
	@Test
	void contextLoads() {
	}
	
	@BeforeEach
	public void setUp() {
		System.out.println("starting up");
	}
	
	@AfterEach
	public void tearDown() {
		System.out.println("ending up");
	}
	
	@Test
	@DisplayName("Sum of two numbers")
	void testDoSum(){
		int expectedValue=30;
		int actualOutput=cal.doSum(10, 10, 10);
		assertThat(actualOutput).isEqualTo(expectedValue);
	}
	
	@Test
	void testDoProduct(){
		int expectedValue=8;
		int actualOutput=cal.doProduct(2, 2, 2);
		assertThat(actualOutput).isEqualTo(expectedValue);
	}
	
	@Test
	void testDoCompare(){
		
		Boolean actualOutput=cal.compareTwoNumbers(2, 2);
		assertThat(actualOutput).isTrue();
	}
	
	
}
;