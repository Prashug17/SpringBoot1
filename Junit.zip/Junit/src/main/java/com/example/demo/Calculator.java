package com.example.demo;

public class Calculator {
	public int doSum(int a,int b,int c) {
		return a+b+c;
	}
	
	public int doProduct(int a,int b,int c) {
		return a*b*c;
	}
	
	public Boolean compareTwoNumbers(int a,int b) {
		return a==b;
	}
}
