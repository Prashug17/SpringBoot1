package com.dao;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;

import com.model.Exam;
import com.model.Student;

public interface ExamRepository extends CrudRepository<Exam, Integer>{
	@Query("FROM Exam e WHERE exam_id=:n ")
	public Exam QuestionPresentById(@Param("n") int exam_id);
}
