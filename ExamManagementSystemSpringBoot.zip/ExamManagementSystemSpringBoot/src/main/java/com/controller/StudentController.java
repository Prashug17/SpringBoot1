package com.controller;

public class StudentController {

}
