package com.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.dao.StudentRepository;
import com.model.Student;

@RestController
@RequestMapping("/api")
public class StudentRestController {
	
	@Autowired
	StudentRepository studRepo;
	
//	Get All Students
	@GetMapping("/student")
	public List<Student> getStudents(){
	 List<Student> list=(List<Student>) studRepo.findAll();
	 System.out.println(list);
	 return list;
	}
	
//	Get student by id
	@GetMapping("/student/{sid}")
	public Student getStudentById(@PathVariable("sid") int id) {
		Student st = new Student();
		Optional<Student> std =studRepo.findById(id);
		st = std.get();
		return st;		
	}
//	add/insert student
	@PostMapping("/student")
	public Student addStudent(@RequestBody Student student) {
		Student st = new Student();
		st.setStudentFirstName(student.getStudentFirstName());
		st.setStudentLastName(student.getStudentLastName());
		st.setStudentGender(student.getStudentGender());
		st.setStudentPassword(student.getStudentPassword());
		st.setStudentAddress(student.getStudentAddress());
		st.setStudentEmail(student.getStudentEmail());
		st.setStudentCourse(student.getStudentCourse());
		studRepo.save(st);
		return st;
	}
//	update student
	@PutMapping("/student/{sid}")
	public Student updateStudent(@RequestBody Student student, @PathVariable("sid") int id) {
		Student st = new Student();
		Optional<Student> std =studRepo.findById(id);
		st = std.get();
		st.setStudentFirstName(student.getStudentFirstName());
		st.setStudentLastName(student.getStudentLastName());
		st.setStudentGender(student.getStudentGender());
		st.setStudentPassword(student.getStudentPassword());
		st.setStudentAddress(student.getStudentAddress());
		st.setStudentEmail(student.getStudentEmail());
		st.setStudentCourse(student.getStudentCourse());
		studRepo.save(st);
		return st;		
	}
	
//	delete student by ID
	@DeleteMapping("/student/{sid}")
	public Student deleteStudentById(@PathVariable("sid") int id) {
		Student st = new Student();
		st= studRepo.findById(id).get();
		studRepo.deleteById(id);
		return st;		
	}
		
}
