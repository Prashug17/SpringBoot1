package com.dao;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import com.model.Flight;

public interface FlightRepository extends CrudRepository<Flight, Integer> {

	
	
}
