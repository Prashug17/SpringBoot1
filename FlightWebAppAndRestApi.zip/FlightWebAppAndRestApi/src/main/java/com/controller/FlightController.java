package com.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.dao.FlightRepository;
import com.model.Flight;

@Controller
@RequestMapping("/flight")
public class FlightController {

	@Autowired
	FlightRepository flightRepo;

	@RequestMapping("/test")
	public String getTest() {
		return "test";
	}

	@RequestMapping("/home")
	public String home() {
		return "home";

	}

	@RequestMapping("/addflight")
	public String addFlight() {
		return "addflight";

	}

	@RequestMapping("/addedsuccess")
	public String addFlightInDb(@ModelAttribute Flight flight, Model model) {
		Flight flig = new Flight();
		flig.setFname(flight.getFname());
		flig.setForigin(flight.getForigin());
		flig.setFdestination(flight.getFdestination());
		flig.setDarrival(flight.getDarrival());
		flig.setDdepart(flight.getDdepart());
		flig.setFpriceeco(flight.getFpriceeco());
		flig.setFpricebus(flight.getFpricebus());

		flightRepo.save(flig);
		System.out.println("Added ");
		model.addAttribute("flight", flight);
		return "addedsuccess";

	}

	@RequestMapping("/updateflight")
	public String updateFlight() {
		return "updateflight";
	}

	@RequestMapping("/updateindb")
	public String updateInDb(@ModelAttribute Flight flight) {
		Flight fli = new Flight();
		Optional<Flight> fig = flightRepo.findById(flight.getFid());
		fli = fig.get();
		fli.setFname(flight.getFname());
		fli.setForigin(flight.getForigin());
		fli.setFdestination(flight.getFdestination());
		fli.setDarrival(flight.getDarrival());
		fli.setDdepart(flight.getDdepart());
		fli.setFpriceeco(flight.getFpriceeco());
		fli.setFpricebus(flight.getFpricebus());

		flightRepo.save(fli);
		return "updatesuccess";

	}

	@RequestMapping("/deleteflight")
	public String deleteFlight() {
		return "deleteflight";

	}

	@RequestMapping("deletefromdb")
	public String deleteFromDatabase(@RequestParam("fid") int fid) {
		flightRepo.deleteById(fid);
		return "deletesuccess";

	}

	@RequestMapping("/getflights")
	public String getAllFlights(Model model) {
		List<Flight> list = (List<Flight>) flightRepo.findAll();
		model.addAttribute("flights", list);
		return "getallflights";

	}

	@RequestMapping("/getflight")
	public String getFlight() {
		return "getflight";

	}

	@RequestMapping("/displayflight")
	public String displayFlight(@RequestParam("fid") int id, Model model) {
		Flight fli = flightRepo.findById(id).get();
		model.addAttribute("flight", fli);
		return "displayflight";

	}
}
