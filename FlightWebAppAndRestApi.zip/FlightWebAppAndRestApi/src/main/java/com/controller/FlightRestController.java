package com.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.dao.FlightRepository;
import com.model.Flight;

import jakarta.validation.Valid;

@RestController
@CrossOrigin(origins = "http://localhost:4200")
@RequestMapping("/api")
public class FlightRestController {

	@Autowired
	FlightRepository flightReo;

	@ExceptionHandler(MethodArgumentNotValidException.class)
	public Map<String, String> handleInvalidArguments(MethodArgumentNotValidException ex) {
		Map<String, String> errorMap = new HashMap<>();
		ex.getBindingResult().getFieldErrors().forEach(error -> {
			errorMap.put(error.getField(), error.getDefaultMessage());
		});
		return errorMap;
	}

//	Get All Flights
	public List<Flight> getFlights() {
		List<Flight> list = (List<Flight>) flightReo.findAll();
		System.out.println(list);
		return list;
	}

//	Get All Flights
//	Using Response Entity Example
	@GetMapping("/flightres")
	public ResponseEntity<List<Flight>> getStudentsWithResponseEntity() {
		List<Flight> list = (List<Flight>) flightReo.findAll();
		System.out.println(list);
		return new ResponseEntity<List<Flight>>(list, HttpStatus.OK);
	}

//	Get flight by id
	@GetMapping("/flight/{fid}")
	public Flight getStudentById(@PathVariable("fid") int fid) {
		Flight fli = new Flight();
		Optional<Flight> fig = flightReo.findById(fid);
		fli = fig.get();
		return fli;
	}
	

//	add/insert flight
	@PostMapping("/flight")
	@PreAuthorize("hasRole('ADMIN')")
	public Flight addFlight(@RequestBody @Valid Flight flight) {
		Flight fli = new Flight();

		fli.setFname(flight.getFname());
		fli.setForigin(flight.getForigin());
		fli.setFdestination(flight.getFdestination());
		fli.setDarrival(flight.getDarrival());
		fli.setDdepart(flight.getDdepart());
		fli.setFpriceeco(flight.getFpriceeco());
		fli.setFpricebus(flight.getFpricebus());
		flightReo.save(fli);
		return fli;
	}

//	update flight
	@PutMapping("/flight/{fid}")
	public Flight updateFlight(@RequestBody Flight flight, @PathVariable("fid") int fid) {
		Flight fli = new Flight();
		Optional<Flight> fig =flightReo.findById(fid);
		fli = fig.get();
		fli.setFname(flight.getFname());
		fli.setForigin(flight.getForigin());
		fli.setFdestination(flight.getFdestination());
		fli.setDarrival(flight.getDarrival());
		fli.setDdepart(flight.getDdepart());
		fli.setFpriceeco(flight.getFpriceeco());
		fli.setFpricebus(flight.getFpricebus());
		flightReo.save(fli);
		return fli;
	}

//	delete flight by ID
	@DeleteMapping("/flight/{fid}")
	public Flight deleteFlightById(@PathVariable("fid") int fid) {
		Flight fli = new Flight();
		fli = flightReo.findById(fid).get();
		flightReo.deleteById(fid);
		return fli;
	}

}
