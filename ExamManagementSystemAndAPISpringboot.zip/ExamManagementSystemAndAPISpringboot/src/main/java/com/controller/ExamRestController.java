package com.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.dao.ExamRepository;
import com.model.Exam;

@RestController
@RequestMapping("/api")
public class ExamRestController {
	@Autowired
	ExamRepository exRepo;
	
//	Get All questions
	@GetMapping("/exam")
	public List<Exam> getStudents(){
	 List<Exam> list=(List<Exam>) exRepo.findAll();
	 System.out.println(list);
	 return list;
	}
	
//	Get question by id
	@GetMapping("/exam/{eid}")
	public Exam getExamById(@PathVariable("eid") int id) {
		Exam ex = new Exam();
		Optional<Exam> ex1 =exRepo.findById(id);
		ex = ex1.get();
		return ex;		
	}
//	add/insert question
	@PostMapping("/exam")
	public Exam addExam(@RequestBody Exam exam) {
		Exam ex = new Exam();
		ex.setExam_id(exam.getExam_id());
		ex.setQuestion(exam.getQuestion());
		ex.setOption1(exam.getOption1());
		ex.setOption2(exam.getOption2());
		ex.setOption3(exam.getOption3());
		ex.setOption4(exam.getOption4());
		ex.setCorrectOption(exam.getCorrectOption());
		exRepo.save(ex);
		return ex;
	}
//	update question
	@PutMapping("/exam/{eid}")
	public Exam updateStudent(@RequestBody Exam exam, @PathVariable("eid") int id) {
		Exam ex = new Exam();
		Optional<Exam> ex1 =exRepo.findById(id);
		ex = ex1.get();
		ex.setExam_id(exam.getExam_id());
		ex.setQuestion(exam.getQuestion());
		ex.setOption1(exam.getOption1());
		ex.setOption2(exam.getOption2());
		ex.setOption3(exam.getOption3());
		ex.setOption4(exam.getOption4());
		ex.setCorrectOption(exam.getCorrectOption());
		exRepo.save(ex);
		return ex;		
	}
	
//	delete question by ID
	@DeleteMapping("/exam/{eid}")
	public Exam deleteStudentById(@PathVariable("eid") int id) {
		Exam ex = new Exam();
		ex= exRepo.findById(id).get();
		exRepo.deleteById(id);
		return ex;		
	}
}
