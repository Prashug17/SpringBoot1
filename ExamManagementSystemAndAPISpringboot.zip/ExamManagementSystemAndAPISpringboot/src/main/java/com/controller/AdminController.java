package com.controller;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.dao.ExamRepository;
import com.dao.StudentRepository;
import com.model.Exam;
import com.model.Student;

@Controller
@RequestMapping("/exam")
public class AdminController {
	
	@Autowired
	StudentRepository stdrep;
	
	@Autowired
	ExamRepository exrep;
	
	
	@RequestMapping("/home")
	public String home() {
		return "home";
	}
	
	@RequestMapping("/examhome")
	public String examhome() {
		return "examhome";
	}
	
	@RequestMapping("/addstudent")
	public String addStudent() {
		return "addstudent";

	}

	@RequestMapping("/addedsuccess")
	public String addStudentInDb(@ModelAttribute Student student, Model model) {
		Student stud = new Student();
		stud.setStudent_id(student.getStudent_id());
		stud.setStudentFirstName(student.getStudentFirstName());
		stud.setStudentLastName(student.getStudentLastName());
		stud.setStudentGender(student.getStudentGender());
		stud.setStudentPassword(student.getStudentPassword());
		stud.setStudentAddress(student.getStudentAddress());
		stud.setStudentEmail(student.getStudentEmail());
		stud.setStudentCourse(student.getStudentCourse());
		
		stdrep.save(stud);
		System.out.println("Added ");
		model.addAttribute("student", student);
		return "addedsuccess";

	}
	
	@RequestMapping("/updatestudent")
	public String updateStudent() {
		return "updatestudent";
	}
	
	@RequestMapping("/updatesuccess")
	public String updatestd(@ModelAttribute Student student) {
		
		Student std = stdrep.StudentPresentById(student.getStudent_id());
		System.out.println(std.getStudentFirstName());
		std.setStudentFirstName(student.getStudentFirstName());
		std.setStudentLastName(student.getStudentLastName());
		std.setStudentGender(student.getStudentGender());
		std.setStudentPassword(student.getStudentPassword());
		std.setStudentAddress(student.getStudentAddress());
		std.setStudentEmail(student.getStudentEmail());
		std.setStudentCourse(student.getStudentCourse());
		stdrep.save(std);
		return "updatesuccess";
	}
	
	@RequestMapping("/getstudent")
	public String getStudent() {
		return "getstudent";

	}
	
	@RequestMapping("/displaystudent")
	public String displayStudent(@RequestParam("sid") int student_id, Model model) {
		Student st = stdrep.findById(student_id).get();
		model.addAttribute("student",st);
		return "displaystudent";
			
	}
	
	@RequestMapping("/deletestudent")
	public String deleteStudent() {
		return "deletestudent";

	}

	@RequestMapping("/deletesuccess")
	public String deleteStudent(@RequestParam("id") int id) {
		stdrep.deleteById(id);
		return "deletesuccess";
	}
	
	@RequestMapping("/addexam")
	public String addExam() {
		return "addexam";
	}
	
	@RequestMapping("/examaddedsuccess")
	public String addExamInDb(@ModelAttribute Exam exam, Model model) {
		Exam ex = new Exam();
		ex.setExam_id(exam.getExam_id());
		ex.setQuestion(exam.getQuestion());
		ex.setOption1(exam.getOption1());
		ex.setOption2(exam.getOption2());
		ex.setOption3(exam.getOption3());
		ex.setOption4(exam.getOption4());
		ex.setCorrectOption(exam.getCorrectOption());
		
		exrep.save(ex);
		System.out.println("Added");
		model.addAttribute("exam", exam);
		return "addedsuccess";
	}
	
	@RequestMapping("/updateexam")
	public String updateExam() {
		return "updateexam";
	}
	
	@RequestMapping("/examupdatesuccess")
	public String updateexam(@ModelAttribute Exam exam) {
		Exam ex = exrep.QuestionPresentById(exam.getExam_id());
		ex.setExam_id(exam.getExam_id());
		ex.setQuestion(exam.getQuestion());
		ex.setOption1(exam.getOption1());
		ex.setOption2(exam.getOption2());
		ex.setOption3(exam.getOption3());
		ex.setOption4(exam.getOption4());
		ex.setCorrectOption(exam.getCorrectOption());
		
		exrep.save(ex);
		return "examupdatesuccess";
	}
	
	@RequestMapping("/deletequestion")
	public String deleteQuestion() {
		return "deletequestion";
	}
	
	@RequestMapping("/deletequesuccess")
	public String deleteFromDatabase(@RequestParam("id") int id) {
		exrep.deleteById(id);
		return "deletequesuccess";
	}
	
	@RequestMapping("/getquestion")
	public String getQuestion() {
		return "getquestion";
	}
	

	@RequestMapping("/displayquestion")
	public String displayQuestion(@RequestParam("sid") int id, Model model) {
		Exam ex = exrep.findById(id).get();
		model.addAttribute("exam",ex);
		return "displayquestion";		
	}
	
	
}
