package com.dao;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;

import com.model.Student;

public interface StudentRepository extends CrudRepository<Student, Integer> {

	@Query("FROM Student s WHERE student_id=:n ")
	public Student StudentPresentById(@Param("n") int student_id);
	
//	@Query("Delete FROM Student s WHERE student_id=:n ")
//	public Student deleteByStdId(@Param("n") int student_id);
	
}
