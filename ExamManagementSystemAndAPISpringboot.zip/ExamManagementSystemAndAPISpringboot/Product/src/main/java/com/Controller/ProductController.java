package com.Controller;

import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


import com.Repository.ProductRepo;
import com.entity.Product;

@RestController
@RequestMapping("/api")
public class ProductController {
	
	@Autowired
	ProductRepo productrepo;
	
	@GetMapping("/products")
	public ResponseEntity<List<Product>> getAll(){
		List<Product> ls=(List<Product>) productrepo.findAll();
		return new ResponseEntity<List<Product>>(ls,HttpStatus.OK);
		}
	@GetMapping("/pord/{productid}")
	public ResponseEntity<Product> getByID(@PathVariable int productid){
		Product p=productrepo.findById(productid).get();
		return new ResponseEntity<Product>(p,HttpStatus.OK);
	}
	@PostMapping("/products")
	public ResponseEntity<Product> postDetails(@RequestBody Product product){
		return new ResponseEntity<Product>(productrepo.save(product),HttpStatus.CREATED);
	}
	@PutMapping("/prod/{productid}")
	public ResponseEntity<Product> updateDetails(@RequestBody Product product,@PathVariable int productid){
		Product p=productrepo.findById(productid).get();
		p.setProductname(product.getProductname());
		p.setProductprice(product.getProductprice());
		p.setProductbrand(product.getProductbrand());
		p.setExpirydate(product.getExpirydate());
		productrepo.save(p);
		return new ResponseEntity<Product>(p,HttpStatus.OK);
	}
	
	@GetMapping("/productsdate/{expirydate}")
	public ResponseEntity<List<Product>> getProductByDate(@PathVariable String expirydate){
		
		List<Product> p=productrepo.findAllByExpirydate(expirydate);
		return new ResponseEntity<List<Product>>(p,HttpStatus.OK);
	}
	
	@GetMapping("/product/{productbrand}")
	public ResponseEntity<List<Product>> getProductBybrand(@PathVariable String productbrand){
		
		List<Product> p=productrepo.findAllByProductbrand(productbrand);
		return new ResponseEntity<List<Product>>(p,HttpStatus.OK);
	}
	
	@GetMapping("/products/{productprice}")
	public ResponseEntity<List<Product>> getProductBybrand(@PathVariable double productprice){
		
		List<Product> p=productrepo.findAllByProductprice(productprice);
		return new ResponseEntity<List<Product>>(p,HttpStatus.OK);
	}
	@DeleteMapping("/prd/{productid}")
	public ResponseEntity<Product> deleteproductById(@PathVariable int productid){
		Product p=productrepo.findById(productid).get();
		productrepo.delete(p);
		return new ResponseEntity<Product>(p,HttpStatus.OK);
	}
	
	

}
