package com.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.dao.ProductRepository;
import com.model.Product;

@RestController
@RequestMapping("/api")
public class ProductRestController {
	@Autowired
	ProductRepository prdrep;
	
	@GetMapping("/products")
	public List<Product> getproducts(){
	 List<Product> list=(List<Product>) prdrep.findAll();
	 System.out.println(list);
	 return list;
	}

	@GetMapping("/product/{product_id}")
	public Product getProductById(@PathVariable("product_id") int id) {
		Product prd=new Product();
		Optional<Product> prod =prdrep.findById(id);
		prd=prod.get();
		return prd;
	}
	
	@PostMapping("/product")
	public Product addProduct(@RequestBody Product product) {
		Product prod = new Product();
		prod.setProduct_id(product.getProduct_id());
		prod.setProduct_name(product.getProduct_name());
		prod.setProduct_price(product.getProduct_price());
		prod.setProduct_brand(product.getProduct_brand());
		prod.setProduct_expirydate(product.getProduct_expirydate());
		prdrep.save(prod);
		return prod;
	}
	
	@PutMapping("/product/{product_id}")
	public Product updateStudent(@RequestBody Product product, @PathVariable("product_id") int id) {
		Product prod = new Product();
		Optional<Product> prd =prdrep.findById(id);
		prod = prd.get();
		prod.setProduct_id(product.getProduct_id());
		prod.setProduct_name(product.getProduct_name());
		prod.setProduct_price(product.getProduct_price());
		prod.setProduct_brand(product.getProduct_brand());
		prod.setProduct_expirydate(product.getProduct_expirydate());
		prdrep.save(prod);
		return prod;
	}
	
	@GetMapping("/product/{product_expirydate}")
	public List<Product> getProductByDate(@PathVariable("product_expirydate") String date) {
		List<Product> prd =prdrep.findByDate(date);
		return prd;		
	}
	
	@GetMapping("/product/{product_brand}")
	public List<Product> getProductsExcept(@PathVariable("product_brand") String brand) {
		List<Product> prd =prdrep.findByBrand(brand);
		return prd;		
	}
	
	@GetMapping("api/product/{product_price}")
	public List<Product> getProductsByPrice(@PathVariable("product_price") int price) {
		List<Product> prd =prdrep.findByPrice(price);
		return prd;		
	}
	
	
}
