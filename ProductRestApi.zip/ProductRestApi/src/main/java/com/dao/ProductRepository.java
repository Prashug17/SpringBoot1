package com.dao;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;


import com.model.Product;

public interface ProductRepository extends CrudRepository<Product,Integer>{
	@Query(value="select * from Products  where product_expirydate=?",nativeQuery=true)
	public List<Product> findByDate(String product_expirydate);
	
	@Query(value="select * from Products  where product_brand!=?",nativeQuery=true)
	public List<Product> findByBrand(String product_brand);
	
	@Query(value="select * from Products  where product_price<?",nativeQuery=true)
	public List<Product> findByPrice(int product_price);

}
