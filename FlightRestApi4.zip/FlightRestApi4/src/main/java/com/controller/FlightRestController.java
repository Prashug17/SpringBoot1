package com.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.dao.BookingRepository;
import com.dao.CustomerRepository;
import com.dao.FlightRepository;
import com.model.Booking;
import com.model.Customer;
import com.model.Flight;


@RestController
@CrossOrigin(origins = "http://localhost:4200")
@RequestMapping("/api")
public class FlightRestController {

	@Autowired
	FlightRepository flightRep;
	
	@Autowired
	CustomerRepository custrep;
	
	@Autowired
	BookingRepository bookrep;
	
	@GetMapping("/flights")
	public List<Flight> getFlights() {
		List<Flight> list = (List<Flight>) flightRep.findAll();
		System.out.println(list);
		return list;
	}
	
	@GetMapping("/flightid/{flight_id}")
	public Flight getFlightById(@PathVariable("flight_id") int fid) {
		Flight fli = new Flight();
		Optional<Flight> fig = flightRep.findById(fid);
		fli = fig.get();
		return fli;
	}
	
	@GetMapping("/flightsource/{flight_source}")
	public List<Flight> getFlightBySource(@PathVariable("flight_source") String source) {
		List<Flight> list =(List<Flight>) flightRep.findBySource(source);
		return list;		
	}
	
	@GetMapping("/flightprice/{flight_price}")
	public List<Flight> getFlightByPriceLessThan(@PathVariable("flight_price") Float price) {
		List<Flight> list =flightRep.findByPriceLessThan(price);
		return list;		
	}
	
	@PreAuthorize("hasRole('ADMIN')")
	@PostMapping("/flight")
	public Flight addFlight(@RequestBody Flight flight) {
		Flight fli = new Flight();
		fli.setFlight_id(flight.getFlight_id());
		fli.setFlight_name(flight.getFlight_name());
		fli.setFlight_date(flight.getFlight_date());
		fli.setFlight_source(flight.getFlight_source());
		fli.setFlight_destination(flight.getFlight_destination());
		fli.setFlight_price(flight.getFlight_price());
		fli.setFlight_duration(flight.getFlight_duration());
		fli.setFlight_capacity(flight.getFlight_capacity());
		flightRep.save(fli);
		return fli;
	}
	
	@PreAuthorize("hasRole('ADMIN')")
	@PutMapping("/putflight/{flight_id}")
	public Flight updateFlight(@RequestBody Flight flight, @PathVariable("flight_id") int fid) {
		Flight fli = new Flight();
		Optional<Flight> fig =flightRep.findById(fid);
		fli = fig.get();
		fli.setFlight_id(flight.getFlight_id());
		fli.setFlight_name(flight.getFlight_name());
		fli.setFlight_date(flight.getFlight_date());
		fli.setFlight_source(flight.getFlight_source());
		fli.setFlight_destination(flight.getFlight_destination());
		fli.setFlight_price(flight.getFlight_price());
		fli.setFlight_duration(flight.getFlight_duration());
		fli.setFlight_capacity(flight.getFlight_capacity());
		flightRep.save(fli);
		return fli;
	}
	
	@PreAuthorize("hasRole('ADMIN')")
	@DeleteMapping("/deleteflight/{flight_id}")
	public Flight deleteFlightById(@PathVariable("flight_id") int fid) {
		Flight fli = new Flight();
		fli = flightRep.findById(fid).get();
		flightRep.deleteById(fid);
		return fli;
	}
	
	@GetMapping("/customers")
	public List<Customer> getCustomers() {
		List<Customer> list = (List<Customer>) custrep.findAll();
		System.out.println(list);
		return list;
	}
	
	@GetMapping("/customerid/{customer_id}")
	public Customer getCustomerById(@PathVariable("customer_id") int cid) {
		Customer customer = new Customer();
		Optional<Customer> cust = custrep.findById(cid);
		customer = cust.get();
		return customer;
	}
	
	@GetMapping("/customername/{customer_name}")
	public List<Customer> getCustomerByName(@PathVariable("customer_name") String name) {
		List<Customer> list = custrep.findByName(name);
		System.out.println(list);
		return list;
	}
	
	@PostMapping("/customer")
	public Customer addCustomer(@RequestBody Customer customer) {
		Customer cust = new Customer();
		cust.setCustomer_id(customer.getCustomer_id());
		cust.setCustomer_name(customer.getCustomer_name());
		cust.setCustomer_username(customer.getCustomer_username());
		cust.setCustomer_password(customer.getCustomer_password());
		cust.setCustomer_email(customer.getCustomer_email());
		cust.setCustom_phone(customer.getCustom_phone());
		custrep.save(cust);
		return cust;
	}
	
	@PutMapping("/putcustomer/{customer_id}")
	public Customer updateCustomer(@RequestBody Customer customer, @PathVariable("customer_id") int cid) {
		Customer cust = new Customer();
		Optional<Customer> cig =custrep.findById(cid);
		cust = cig.get();
		cust.setCustomer_id(customer.getCustomer_id());
		cust.setCustomer_name(customer.getCustomer_name());
		cust.setCustomer_username(customer.getCustomer_username());
		cust.setCustomer_password(customer.getCustomer_password());
		cust.setCustomer_email(customer.getCustomer_email());
		cust.setCustom_phone(customer.getCustom_phone());
		custrep.save(cust);
		return cust;
	}
	
	@DeleteMapping("/deletecustomer/{customer_id}")
	public Customer deleteCustomerById(@PathVariable("customer_id") int cid) {
		Customer cust = new Customer();
		cust = custrep.findById(cid).get();
		custrep.deleteById(cid);
		return cust;
	}
	
	@GetMapping("/bookings")
	public List<Booking> getBookings() {
		List<Booking> list = (List<Booking>) bookrep.findAll();
		System.out.println(list);
		return list;
	}
	
	@GetMapping("/bookingid/{booking_id}")
	public Booking getBookingById(@PathVariable("booking_id") int bid) {
		Booking book = new Booking();
		Optional<Booking> bk = bookrep.findById(bid);
		book = bk.get();
		return book;
	}
	
	
	@DeleteMapping("/deletebooking/{booking_id}")
	public Booking deleteBookingById(@PathVariable("booking_id") int bid) {
		Booking book = new Booking();
		book = bookrep.findById(bid).get();
		bookrep.deleteById(bid);
		return book;
	}
		
}
