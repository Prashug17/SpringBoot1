package com.dao;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import com.model.Customer;


public interface CustomerRepository extends CrudRepository<Customer, Integer>{

	@Query(value="select * from customer  where customer_name=?",nativeQuery=true)
	public List<Customer> findByName(String customer_name);
}
