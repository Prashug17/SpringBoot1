package com.dao;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import com.model.Flight;


public interface FlightRepository extends CrudRepository<Flight, Integer>{

	@Query(value="select * from flight  where flight_source=?",nativeQuery=true)
	public List<Flight> findBySource(String flight_source);
	
	@Query(value="select * from flight  where flight_price<?",nativeQuery=true)
	public List<Flight> findByPriceLessThan(Float flight_price);
	
	@Query(value="select * from flight where flight_date=? AND flight_source=? AND flight_destination=?",nativeQuery=true)
	public List<Flight> fingBySourceAndDate(String date,String source,String destination);
}
